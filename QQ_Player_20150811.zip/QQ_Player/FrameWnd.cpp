#include "resource.h"
#include "FrameWnd.h"
//#include "MenuWnd.h"

CFrameWnd::CFrameWnd( LPCTSTR pszXMLPath )
: CXMLWnd(pszXMLPath)
{

}

void CFrameWnd::InitWindow()
{
//    SetIcon(IDR_MAINFRAME); // ����������ͼ��
    CenterWindow();

    // ��ʼ��CProgressUI�ؼ�
//     CProgressUI* pProgress = static_cast<CProgressUI*>(m_PaintManager.FindControl(_T("ProgressDemo1")));    
//     pProgress->SetValue(100);

}

void CFrameWnd::Notify( TNotifyUI& msg )
{
    if( msg.sType == _T("click") ) 
    {
        if( msg.pSender->GetName() == _T("btnMenu") ) 
        {
        }
    }
    else if(msg.sType == _T("selectchanged"))
    {

    }

    __super::Notify(msg);
}

CControlUI* CFrameWnd::CreateControl( LPCTSTR pstrClassName )
{
    if (_tcsicmp(pstrClassName, _T("Wnd")) == 0)
    {

    }

    return NULL;
}

